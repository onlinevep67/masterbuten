/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * A list of Kingdom Melodies with thematic hints.
 * NOTE: These are placeholder audio files from a public domain source.
 * Direct streaming from jw.org is not permitted or technically feasible. These
 * URLs should be replaced with legitimately hosted audio files if available.
 */
const MELODIES = [
  // Theme: Praising Jehovah
  {
    name: "Jehovah's Attributes",
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
  },
  {
    name: 'Jehovah Is Your Name',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
  },
  {
    name: 'We Thank You, Jehovah',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
  },
  // Theme: Pagbabalik-loob (Returning to Jehovah)
  {
    name: 'Please Hear My Prayer',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
  },
  {
    name: '“A Perfect Wage” From Jehovah',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',
  },
  {
    name: 'He Will Make You Strong',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3',
  },
];

/**
 * A list of dramatic Bible readings.
 * NOTE: Placeholder audio files.
 */
const BIBLE_READINGS = [
  {
    name: 'The Story of Josiah: Love Jehovah; Hate What Is Bad',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
  },
  {
    name: 'Jehovah Delivers His People',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3',
  },
];

/**
 * BrotherRem is a client-side agent responsible for playing Kingdom
 * Melodies and Bible readings based on time or user command. It ensures
 * playback can happen in the background during other activities.
 */
export class BrotherRem {
  private audioElement: HTMLAudioElement;
  private playlist: string[] = [];
  private currentTrackIndex = 0;
  private isPlaying = false;

  constructor(audioElement: HTMLAudioElement) {
    this.audioElement = audioElement;
    // When one track ends, play the next one in the queue.
    this.audioElement.addEventListener('ended', () => this.playNext());
  }

  /**
   * Main entry point. Decides what content to play (melodies or reading),
   * builds a playlist, and starts playback.
   */
  public startPlayback() {
    if (this.isPlaying) {
      console.log('Brother Rem is already playing content.');
      return;
    }

    // Decide whether to play melodies or a Bible reading (75% chance for melodies)
    if (Math.random() < 0.75) {
      this.prepareMelodyPlaylist();
    } else {
      this.prepareBibleReadingPlaylist();
    }

    this.isPlaying = true;
    this.currentTrackIndex = 0;
    this.playTrack(this.currentTrackIndex);
  }

  /**
   * Creates a shuffled playlist of three melodies.
   */
  private prepareMelodyPlaylist() {
    console.log('Brother Rem is preparing a melody playlist.');
    // Shuffle melodies and pick 3 to create a short, varied playlist.
    const shuffled = [...MELODIES].sort(() => 0.5 - Math.random());
    this.playlist = shuffled.slice(0, 3).map((m) => m.url);
  }

  /**
   * Creates a playlist with a single, randomly chosen Bible reading.
   */
  private prepareBibleReadingPlaylist() {
    console.log('Brother Rem is preparing a Bible reading.');
    // Pick one random reading.
    const reading =
      BIBLE_READINGS[Math.floor(Math.random() * BIBLE_READINGS.length)];
    this.playlist = [reading.url];
  }

  /**
   * Plays a specific track from the current playlist by its index.
   * @param index The index of the track to play.
   */
  private playTrack(index: number) {
    // If we've reached the end of the playlist, stop and reset.
    if (index >= this.playlist.length) {
      this.isPlaying = false;
      this.playlist = []; // Clear the completed playlist.
      console.log('Brother Rem finished the playlist.');
      return;
    }

    this.audioElement.src = this.playlist[index];
    this.audioElement.play().catch((e) => {
      console.error(
        `Brother Rem failed to play audio track ${index}:`,
        e.message,
      );
      // If playback fails (e.g., browser policy), stop the process.
      this.isPlaying = false;
    });
  }

  /**
   * Advances to the next track in the playlist. Called when a track ends.
   */
  private playNext() {
    this.currentTrackIndex++;
    this.playTrack(this.currentTrackIndex);
  }
}

/// <reference types="vite/client" />
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {GoogleGenAI, Type} from '@google/genai';

// Financial data structure from Magnus's analysis
export interface FinancialData {
  income: number;
  expenses: number;
  summary: string;
}

// Initialize a separate client for Magnus, can reuse the main one if preferred
const ai = new GoogleGenAI({apiKey: import.meta.env.VITE_GEMINI_API_KEY});

const financialSchema = {
  type: Type.OBJECT,
  properties: {
    income: {
      type: Type.NUMBER,
      description: 'Total amount of income mentioned in the conversation.',
    },
    expenses: {
      type: Type.NUMBER,
      description:
        'Total amount of expenses or money spent mentioned in the conversation.',
    },
    summary: {
      type: Type.STRING,
      description:
        'A brief one-sentence summary of the financial transactions detected.',
    },
  },
  required: ['income', 'expenses', 'summary'],
};

/**
 * Analyzes a conversation transcript to extract financial information.
 * @param transcript The user's side of the conversation.
 * @returns A promise that resolves to a FinancialData object.
 */
export async function analyzeFinancials(
  transcript: string,
): Promise<FinancialData> {
  // If there's no transcript, no need to call the API.
  if (!transcript.trim()) {
    return {income: 0, expenses: 0, summary: 'No new conversational data.'};
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Analyze the following conversation transcript for financial information. Identify any income (papasok na pera) or expenses (lumabas na pera). \n\nTranscript:\n${transcript}`,
      config: {
        systemInstruction:
          "You are Magnus, a financial analysis agent for Master E. Your task is to extract income and expense figures from a conversation. If no financial data is mentioned, return 0 for both income and expenses and state that in the summary. Your response must be in JSON.",
        responseMimeType: 'application/json',
        responseSchema: financialSchema,
      },
    });

    const jsonText = response.text.trim();
    const data: FinancialData = JSON.parse(jsonText);
    return data;
  } catch (e) {
    console.error('Magnus financial analysis failed:', e);
    // Return a default object on failure to avoid breaking the app
    return {income: 0, expenses: 0, summary: 'Financial analysis failed.'};
  }
}
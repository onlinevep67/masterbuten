import { defineConfig } from 'vite'

// https://vitejs.dev/config/
export default defineConfig({
  // This is needed to ensure that the environment variables from your .env file
  // are correctly exposed to your frontend code.
  // VITE_ is the required prefix for variables.
  envPrefix: 'VITE_',
})

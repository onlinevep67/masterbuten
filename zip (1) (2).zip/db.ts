/// <reference types="vite/client" />
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {createClient, SupabaseClient} from '@supabase/supabase-js';
import {IDBPDatabase, openDB} from 'idb';

const PUBLIC_SUPABASE_URL = import.meta.env.VITE_PUBLIC_SUPABASE_URL;
const PUBLIC_SUPABASE_ANON_KEY = import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY;

if (!PUBLIC_SUPABASE_URL || !PUBLIC_SUPABASE_ANON_KEY) {
  throw new Error(
    'Supabase URL and Anon Key are required. Please check your .env file.',
  );
}

export const supabase: SupabaseClient = createClient(
  PUBLIC_SUPABASE_URL,
  PUBLIC_SUPABASE_ANON_KEY,
);

const DB_NAME = 'MaximusMemoryDB';
const STORE_NAME = 'conversations';
const DB_VERSION = 1;

// Initialize IndexedDB
async function getDb(): Promise<IDBPDatabase> {
  return openDB(DB_NAME, DB_VERSION, {
    upgrade(db) {
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, {keyPath: 'id'});
      }
    },
  });
}

export interface ConversationRecord {
  id?: number;
  created_at?: string;
  name: string;
  transcript: string | null;
  soap_response: string | null;
  icd_code: string | null;
  json_response: string | null;
  timestamp: string;
  audio_url: string | null;
}

// Function to save conversation
export async function saveConversation(
  audioBlob: Blob,
  transcript: string,
): Promise<ConversationRecord> {
  const timestamp = new Date();
  const fileName = `user-audio-${timestamp.toISOString()}.wav`;
  const bucketName = 'conversations';

  // 1. Upload audio to Supabase Storage
  const {data: uploadData, error: uploadError} = await supabase.storage
    .from(bucketName)
    .upload(fileName, audioBlob, {
      cacheControl: '3600',
      upsert: false,
    });

  if (uploadError) {
    console.error('Error uploading audio to Supabase:', uploadError);
    throw new Error('Failed to upload audio.');
  }

  // 2. Get public URL
  const {data: urlData} = supabase.storage
    .from(bucketName)
    .getPublicUrl(uploadData.path);
  const publicUrl = urlData.publicUrl;

  // 3. Insert record into Supabase table
  const conversationName = `Conversation from ${timestamp.toLocaleString()}`;
  const recordToInsert = {
    name: conversationName,
    timestamp: timestamp.toISOString(),
    audio_url: publicUrl,
    transcript: transcript,
    json_response: null, // Magnus will fill this in via a backend process
    soap_response: null,
    icd_code: null,
  };

  const {data: dbData, error: dbError} = await supabase
    .from('conversations')
    .insert([recordToInsert] as any)
    .select()
    .single();

  if (dbError) {
    console.error('Error saving conversation to Supabase:', dbError);
    // Attempt to delete the uploaded file if DB insert fails
    await supabase.storage.from(bucketName).remove([fileName]);
    throw new Error('Failed to save conversation record.');
  }

  const savedRecord: ConversationRecord = dbData;

  // 4. Save to IndexedDB cache
  const db = await getDb();
  await db.put(STORE_NAME, savedRecord);

  return savedRecord;
}

// Function to get conversation history.
// Fetches from Supabase as the source of truth and updates the local cache.
export async function getConversationHistory(): Promise<ConversationRecord[]> {
  const db = await getDb();
  try {
    // 1. Fetch from Supabase (source of truth)
    const {data, error} = await supabase
      .from('conversations')
      .select('*')
      .order('created_at', {ascending: false});

    if (error) {
      throw error;
    }

    if (data) {
      const remoteRecords: ConversationRecord[] = data;
      // 2. Clear local cache and repopulate
      const tx = db.transaction(STORE_NAME, 'readwrite');
      await tx.store.clear();
      for (const record of remoteRecords) {
        await tx.store.put(record);
      }
      await tx.done;
      return remoteRecords;
    }

    return []; // Return empty array if data is null, without touching cache
  } catch (e) {
    console.warn('Supabase fetch failed, falling back to local cache.', e);
    // Fallback to local data if remote fails
    const records: ConversationRecord[] = await db.getAll(STORE_NAME);
    return records.sort(
      (a, b) =>
        new Date(b.created_at || 0).getTime() -
        new Date(a.created_at || 0).getTime(),
    );
  }
}
# Maximus AI Clan: System Architecture & Deployment

This document outlines the architecture for integrating AI agents into the system alongside Maximus (voice interface), Magnus (financial analyst), and Brother Rem (spiritual reminder). It also provides detailed instructions for deployment.

## Core Architecture: Transcription as the Event Bus

The multi-agent system revolves around the `conversations` table in our Supabase database. This table acts as a central, asynchronous message bus. Agents do not communicate directly; they react to data changes in this table.

**The Workflow:**

1.  **User Interaction**: The user speaks.
2.  **Maximus (Transcription)**: Maximus listens, processes the audio in real-time, and generates a final, accurate transcript of the user's speech.
3.  **Event Creation**: Maximus saves the final transcript and the audio recording to a new row in the `conversations` table in Supabase. This `INSERT` is the core event.
4.  **Asynchronous Agent Activation**: This new row triggers other agents:
    *   **Magnus (Analysis)**: Is invoked immediately on the client-side, reads the transcript, performs its financial analysis, and updates the same row with the results in the `json_response` column.
    *   **(Future Agents)**: Serverless functions (e.g., Supabase Edge Functions) can be configured to listen for these `INSERT` events to perform their own tasks asynchronously (e.g., web searches, report generation).
5.  **Data Consolidation**: The `conversations` row becomes the single source of truth for that interaction, enriched with data from all relevant agents.

This decoupled architecture allows us to add, remove, or update agents independently without affecting the core application or other agents.

---

## Agent Roster

Each agent is designed with a specific purpose and uses a model tailored for its task.

| Agent | Purpose | Gemini Model |
| :--- | :--- | :--- |
| **Maximus** | Primary voice interface, real-time transcription, and general assistance. Exceptionally versatile with English, Filipino, and Philippine dialects. | `gemini-2.5-flash-preview-native-audio-dialog` |
| **Magnus** | Financial analyst. Scans transcripts for mentions of income and expenses and structures the data. | `gemini-2.5-flash` |
| **Brother Rem** | Spiritual reminder agent. Plays Kingdom Melodies and Bible readings at scheduled times or on command. | N/A (Client-side audio player) |

---

## Deployment

The application is built with Vite and can be deployed to any static hosting provider.

**Prerequisites:**

1.  **Fork this Repository**: Create your own copy of this repository on GitHub.
2.  **Supabase Account**: Get your Supabase Project URL and Anon Key.
3.  **Gemini API Key**: Get your Google AI Gemini API Key.

### Environment Variables

You will need to set the following environment variables on your deployment platform:

-   `VITE_GEMINI_API_KEY`: Your Gemini API Key.
-   `VITE_PUBLIC_SUPABASE_URL`: Your Supabase project URL.
-   `VITE_PUBLIC_SUPABASE_ANON_KEY`: Your Supabase project anon key.

### Option 1: Deploying to Vercel / Netlify (Recommended)

1.  **Connect Your Repository**: Log in to Vercel or Netlify and import the repository you forked.
2.  **Configure Project Settings**:
    *   The platform should auto-detect that it's a Vite project. If not, set the build command to `npm run build` or `vite build` and the output directory to `dist`.
    *   Go to the project's settings and add the environment variables listed above.
3.  **Deploy**: Trigger a deployment. The platform will build the application and host it on its global CDN.

### Option 2: Deploying to a VPS (e.g., Hostinger, DigitalOcean)

This guide assumes you are using an Ubuntu server.

1.  **SSH into your Server**:
    ```bash
    ssh your_user@your_server_ip
    ```

2.  **Install Dependencies (Node.js, npm, Git)**:
    ```bash
    sudo apt update
    sudo apt install -y nodejs npm git
    ```

3.  **Clone Your Repository**:
    ```bash
    git clone https://github.com/your-username/your-repo-name.git
    cd your-repo-name
    ```

4.  **Install Project Dependencies**:
    ```bash
    npm install
    ```

5.  **Set Environment Variables**:
    Create a `.env` file in the root of your project. **Do not commit this file to Git.**
    ```bash
    # .env
    VITE_GEMINI_API_KEY="your_gemini_key"
    VITE_PUBLIC_SUPABASE_URL="your_supabase_url"
    VITE_PUBLIC_SUPABASE_ANON_KEY="your_supabase_anon_key"
    ```
    Vite will automatically load these variables during the build process.

6.  **Build the Application**:
    ```bash
    npm run build
    ```
    This command compiles the application into static files in the `dist/` directory.

7.  **Install and Configure Nginx**:
    Nginx will serve your static files.
    ```bash
    sudo apt install -y nginx
    ```
    Create a new Nginx configuration file for your site:
    ```bash
    sudo nano /etc/nginx/sites-available/your-domain.com
    ```
    Paste the following configuration, replacing `your-domain.com` and the `root` path:
    ```nginx
    server {
        listen 80;
        server_name your-domain.com www.your-domain.com;

        # The root directory where your built project is located
        root /path/to/your-repo-name/dist;

        index index.html;

        location / {
            try_files $uri $uri/ /index.html;
        }
    }
    ```

8.  **Enable the Nginx Site**:
    ```bash
    # Link the config file to the sites-enabled directory
    sudo ln -s /etc/nginx/sites-available/your-domain.com /etc/nginx/sites-enabled/

    # Test for syntax errors
    sudo nginx -t

    # Restart Nginx to apply changes
    sudo systemctl restart nginx
    ```

9.  **(Optional) Setup SSL with Let's Encrypt**:
    For HTTPS, install Certbot and have it automatically configure Nginx.
    ```bash
    sudo apt install -y certbot python3-certbot-nginx
    sudo certbot --nginx -d your-domain.com -d www.your-domain.com
    ```
    Your application is now live and secure.

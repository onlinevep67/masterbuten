/// <reference types="vite/client" />
/* tslint:disable */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {GoogleGenAI, LiveServerMessage, Modality, Session} from '@google/genai';
import {LitElement, css, html} from 'lit';
import {customElement, state} from 'lit/decorators.js';
import {ifDefined} from 'lit/directives/if-defined.js';
import {
  ConversationRecord,
  getConversationHistory,
  saveConversation,
  supabase,
} from './db';
import {FinancialData, analyzeFinancials} from './magnus';
import {BrotherRem} from './rem';
import {createBlob, decode, decodeAudioData, pcmToWav} from './utils';
import './visual-3d';

// VAD Constants
const SILENCE_THRESHOLD = 0.01; // Root Mean Square (RMS) volume threshold for silence
const SILENCE_DURATION_MS = 2000; // 2 seconds of silence triggers recording stop

@customElement('gdm-live-audio')
export class GdmLiveAudio extends LitElement {
  @state() isRecording = false;
  @state() private showSettings = false;
  @state() private history: ConversationRecord[] = [];
  @state() private dailyFinancials: FinancialData = {
    income: 0,
    expenses: 0,
    summary: 'No financial activity tracked yet.',
  };
  @state() private sessionTranscript = '';

  private client: GoogleGenAI;
  private session: Session;
  private inputAudioContext = new (window.AudioContext ||
    (window as any).webkitAudioContext)({sampleRate: 16000});
  private outputAudioContext = new (window.AudioContext ||
    (window as any).webkitAudioContext)({sampleRate: 24000});
  inputNode = this.inputAudioContext.createGain();
  outputNode = this.outputAudioContext.createGain();
  private nextStartTime = 0;
  private mediaStream: MediaStream;
  private sourceNode: AudioBufferSourceNode;
  private scriptProcessorNode: ScriptProcessorNode;
  private sources = new Set<AudioBufferSourceNode>();
  private userAudioChunks: Float32Array[] = [];
  private vadTimeout: number | null = null; // Voice Activity Detection timer

  // Brother Rem agent
  private brotherRem: BrotherRem;
  private remAudioElement: HTMLAudioElement;
  private timeCheckInterval: number | null = null;
  private lastTriggeredHour = -1; // Prevents re-triggering within the same hour

  static styles = css`
    :host {
      width: 100vw;
      height: 100vh;
      display: block;
      color: white;
      font-family: sans-serif;
      background: #100c14;
      position: relative;
    }

    .panel {
      background: rgba(0, 0, 0, 0.3);
      border-radius: 8px;
      padding: 10px 15px;
      backdrop-filter: blur(5px);
      border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .panel h3 {
      margin: 0 0 10px 0;
      font-size: 16px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);
      padding-bottom: 5px;
    }

    .panel ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .panel li {
      font-size: 12px;
      padding: 5px 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .panel p {
      font-size: 12px;
      font-style: italic;
      color: #ccc;
    }

    .panel a {
      color: #a7c7ff;
      text-decoration: none;
    }

    .panel a:hover {
      text-decoration: underline;
    }

    .financial-summary span {
      display: block;
      font-size: 14px;
      margin-top: 5px;
    }
    .income {
      color: #4ade80; /* green-400 */
    }
    .expenses {
      color: #f87171; /* red-400 */
    }

    .controls {
      z-index: 10;
      position: absolute;
      bottom: 10vh;
      left: 0;
      right: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      gap: 20px;
    }

    .puck {
      width: 80px;
      height: 80px;
      background: #c80000;
      border-radius: 50%;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 4px solid rgba(255, 255, 255, 0.5);
      transition: all 0.2s ease-in-out;
    }
    .puck:hover {
      transform: scale(1.05);
    }
    .puck.recording {
      animation: pulse 1.5s infinite;
      background-color: #ff4d4d;
      border-color: white;
    }
    @keyframes pulse {
      0% {
        transform: scale(0.95);
        box-shadow: 0 0 0 0 rgba(255, 77, 77, 0.7);
      }
      70% {
        transform: scale(1.1);
        box-shadow: 0 0 0 20px rgba(255, 77, 77, 0);
      }
      100% {
        transform: scale(0.95);
        box-shadow: 0 0 0 0 rgba(255, 77, 77, 0);
      }
    }

    .settings-icon {
      position: absolute;
      top: 20px;
      right: 20px;
      z-index: 20;
      cursor: pointer;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 50%;
      width: 48px;
      height: 48px;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 1px solid rgba(255, 255, 255, 0.2);
    }
    .settings-icon:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    .settings-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(10, 5, 15, 0.8);
      backdrop-filter: blur(10px);
      z-index: 100;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 20px;
      box-sizing: border-box;
    }

    .settings-header {
      width: 100%;
      max-width: 800px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }

    .settings-header h2 {
      color: white;
      margin: 0;
      font-size: 24px;
    }

    .close-button {
      background: none;
      border: none;
      color: white;
      font-size: 40px;
      cursor: pointer;
      line-height: 1;
      padding: 0 10px;
    }
    .close-button:hover {
      opacity: 0.8;
    }

    .settings-content {
      display: flex;
      gap: 20px;
      width: 100%;
      max-width: 800px;
      justify-content: center;
    }

    .settings-content .panel {
      width: 350px;
      max-height: 75vh;
      overflow-y: auto;
    }

    @media (max-width: 768px) {
      .settings-content {
        flex-direction: column;
        align-items: center;
      }
      .settings-content .panel {
        width: 90%;
        max-width: 400px;
      }
    }
  `;

  constructor() {
    super();
    this.initClient();
    this.loadHistory();
    this.remAudioElement = new Audio();
    this.brotherRem = new BrotherRem(this.remAudioElement);
    this.startTimeBasedTrigger();
  }

  disconnectedCallback() {
    super.disconnectedCallback();
    if (this.timeCheckInterval) {
      clearInterval(this.timeCheckInterval);
    }
  }

  private startTimeBasedTrigger() {
    this.timeCheckInterval = window.setInterval(() => {
      // Get current time in Philippine time zone (UTC+8)
      const phTimeString = new Date().toLocaleString('en-US', {
        timeZone: 'Asia/Manila',
      });
      const phTime = new Date(phTimeString);
      const hour = phTime.getHours();
      const minute = phTime.getMinutes();

      // Trigger at 9:00 AM or 4:00 PM (16:00)
      if ((hour === 9 || hour === 16) && minute === 0) {
        if (this.lastTriggeredHour !== hour) {
          console.log(`Time trigger for Brother Rem at ${hour}:00 PH time.`);
          this.brotherRem.startPlayback();
          this.lastTriggeredHour = hour; // Mark this hour as triggered
        }
      } else {
        // Reset the trigger lock once we are out of the triggered hour
        if (this.lastTriggeredHour !== -1 && this.lastTriggeredHour !== hour) {
          this.lastTriggeredHour = -1;
        }
      }
    }, 60 * 1000); // Check every minute
  }

  private checkForRemCommand(transcript: string) {
    const lowerTranscript = transcript.toLowerCase();
    const commandDetected =
      lowerTranscript.includes('brother rem') &&
      (lowerTranscript.includes('play melodies') ||
        lowerTranscript.includes('play music'));

    if (commandDetected) {
      console.log('Command trigger for Brother Rem.');
      this.brotherRem.startPlayback();
    }
  }

  private async loadHistory() {
    try {
      this.history = await getConversationHistory();
      this.recalculateDailyFinancials();
    } catch (e) {
      console.error('Failed to load history', e);
    }
  }

  private recalculateDailyFinancials() {
    const today = new Date().toISOString().slice(0, 10);
    let totalIncome = 0;
    let totalExpenses = 0;

    const todaysRecords = this.history.filter(
      (rec) => rec.created_at?.slice(0, 10) === today,
    );

    for (const record of todaysRecords) {
      if (record.json_response) {
        try {
          // In case json_response is a string, parse it.
          const financialData: FinancialData =
            typeof record.json_response === 'string'
              ? JSON.parse(record.json_response)
              : record.json_response;

          if (financialData) {
            totalIncome += financialData.income || 0;
            totalExpenses += financialData.expenses || 0;
          }
        } catch (e) {
          console.error(
            'Failed to parse financial data from record',
            record,
            e,
          );
        }
      }
    }

    this.dailyFinancials = {
      income: totalIncome,
      expenses: totalExpenses,
      summary:
        todaysRecords.length > 0
          ? 'Todays financial summary.'
          : 'No financial activity tracked yet.',
    };
  }

  private initAudio() {
    this.nextStartTime = this.outputAudioContext.currentTime;
  }

  private async initClient() {
    this.initAudio();

    this.client = new GoogleGenAI({
      apiKey: import.meta.env.VITE_GEMINI_API_KEY,
    });

    this.outputNode.connect(this.outputAudioContext.destination);

    this.initSession();
  }

  private async initSession() {
    const model = 'gemini-2.5-flash-preview-native-audio-dialog';
    const maximusSystemInstruction = `You are Maximus, a hyper-intelligent AI assistant for Master E. Your primary function is to understand and accurately transcribe spoken language, then respond helpfully. You must be exceptionally versatile with languages. You are expected to understand English, Filipino (Tagalog), and various Philippine dialects.

Your linguistic model has been enhanced with resources for Ibanag (see https://www.jw.org/ibg/) and Itawit/Itawes (see https://www.jw.org/ibg/library/?contentLanguageFilter=itv). Prioritize understanding these dialects. Even if the transcription is imperfect, use your analytical abilities to infer Master E's intent and what he is trying to point out, as context is often more important than the literal words. Be adaptive and learn from each interaction.

Furthermore, an important part of your duty is to support Master E's well-being in all aspects of his life. Periodically, and when appropriate, gently remind him to attend his weekly "Pulong" (Bible Study). Encourage him that taking action on spiritual matters is as vital as his work in technology and material pursuits, as this is important to him as one of Jehovah's Witnesses.`;

    try {
      this.session = await this.client.live.connect({
        model: model,
        callbacks: {
          onmessage: async (message: LiveServerMessage) => {
            if ('userContent' in message) {
              // The `message.userContent` property is not always well-typed.
              // Casting to `any` provides a pragmatic path to access nested properties.
              const userContent = (message as any).userContent;
              if (userContent?.speechRecognitionResult?.results?.[0]) {
                const transcript =
                  userContent.speechRecognitionResult.results[0].transcript;
                if (transcript) {
                  this.sessionTranscript = transcript;
                  this.checkForRemCommand(transcript);
                }
              }
            } else if ('serverContent' in message) {
              const audio =
                message.serverContent?.modelTurn?.parts[0]?.inlineData;
              if (audio) {
                this.nextStartTime = Math.max(
                  this.nextStartTime,
                  this.outputAudioContext.currentTime,
                );

                const audioBuffer = await decodeAudioData(
                  decode(audio.data),
                  this.outputAudioContext,
                  24000,
                  1,
                );
                const source = this.outputAudioContext.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(this.outputNode);
                source.addEventListener('ended', () => {
                  this.sources.delete(source);
                });

                source.start(this.nextStartTime);
                this.nextStartTime = this.nextStartTime + audioBuffer.duration;
                this.sources.add(source);
              }

              if (message.serverContent?.interrupted) {
                for (const source of this.sources.values()) {
                  source.stop();
                  this.sources.delete(source);
                }
                this.nextStartTime = 0;
              }
            }
          },
          onerror: (e: ErrorEvent) => {
            console.error(e.message);
          },
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            languageCode: 'en-US',
            voiceConfig: {prebuiltVoiceConfig: {voiceName: 'Orus'}},
          },
          systemInstruction: maximusSystemInstruction,
        },
      });
    } catch (e) {
      console.error(e);
      console.error(`Failed to initialize session: ${(e as Error).message}`);
    }
  }

  private toggleRecording() {
    if (this.isRecording) {
      this.stopRecording();
    } else {
      this.startRecording();
    }
  }

  private async startRecording() {
    if (this.isRecording) {
      return;
    }
    this.userAudioChunks = [];
    this.sessionTranscript = '';
    this.inputAudioContext.resume();

    try {
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: false,
      });

      this.sourceNode = this.inputAudioContext.createMediaStreamSource(
        this.mediaStream,
      );
      this.sourceNode.connect(this.inputNode);

      const bufferSize = 256;
      this.scriptProcessorNode = this.inputAudioContext.createScriptProcessor(
        bufferSize,
        1,
        1,
      );

      this.scriptProcessorNode.onaudioprocess = (audioProcessingEvent) => {
        if (!this.isRecording) return;
        const pcmData = audioProcessingEvent.inputBuffer.getChannelData(0);

        // --- Voice Activity Detection (VAD) Logic ---
        let sum = 0;
        for (let i = 0; i < pcmData.length; i++) {
          sum += pcmData[i] * pcmData[i];
        }
        const rms = Math.sqrt(sum / pcmData.length);

        if (rms > SILENCE_THRESHOLD) {
          // Speech detected, clear any existing silence timer
          if (this.vadTimeout) {
            clearTimeout(this.vadTimeout);
            this.vadTimeout = null;
          }
        } else {
          // Silence detected, start/continue timer to stop recording
          if (!this.vadTimeout) {
            this.vadTimeout = window.setTimeout(() => {
              this.stopRecording();
            }, SILENCE_DURATION_MS);
          }
        }
        // --- End VAD Logic ---

        this.session.sendRealtimeInput({media: createBlob(pcmData)});
        this.userAudioChunks.push(new Float32Array(pcmData));
      };

      this.sourceNode.connect(this.scriptProcessorNode);
      this.scriptProcessorNode.connect(this.inputAudioContext.destination);

      this.isRecording = true;
    } catch (err) {
      console.error('Error starting recording:', err);
      this.stopRecording();
    }
  }

  private stopRecording() {
    if (!this.isRecording || !this.mediaStream || !this.inputAudioContext)
      return;

    this.isRecording = false;

    // Clear VAD timer
    if (this.vadTimeout) {
      clearTimeout(this.vadTimeout);
      this.vadTimeout = null;
    }

    if (this.scriptProcessorNode && this.sourceNode && this.inputAudioContext) {
      this.scriptProcessorNode.disconnect();
      this.sourceNode.disconnect();
    }

    this.scriptProcessorNode = null;
    this.sourceNode = null;

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }

    this.saveRecordedAudio();
  }

  private async saveRecordedAudio() {
    if (this.userAudioChunks.length === 0 || !this.sessionTranscript.trim()) {
      return;
    }
    const transcriptToSave = this.sessionTranscript.trim();

    try {
      const totalLength = this.userAudioChunks.reduce(
        (acc, val) => acc + val.length,
        0,
      );
      const combinedPcm = new Float32Array(totalLength);
      let offset = 0;
      for (const chunk of this.userAudioChunks) {
        combinedPcm.set(chunk, offset);
        offset += chunk.length;
      }
      this.userAudioChunks = [];

      const wavBlob = pcmToWav(
        combinedPcm,
        this.inputAudioContext.sampleRate,
      );

      // Save initial record
      const savedRecord = await saveConversation(wavBlob, transcriptToSave);

      // Immediately run Magnus analysis and update the record
      if (savedRecord && savedRecord.id && savedRecord.transcript) {
        try {
          const financialData = await analyzeFinancials(
            savedRecord.transcript,
          );
          if (financialData) {
            const updatePayload: Partial<ConversationRecord> = {
              json_response: JSON.stringify(financialData),
            };
            const {error: updateError} = await supabase
              .from('conversations')
              .update(updatePayload as any)
              .eq('id', savedRecord.id);

            if (updateError) {
              console.error(
                'Error updating record with Magnus analysis:',
                updateError,
              );
            }
          }
        } catch (analysisError) {
          console.error('Magnus analysis failed on client:', analysisError);
        }
      }

      await this.loadHistory(); // Reloads history and recalculates financials
    } catch (err) {
      console.error('Error saving conversation or running analysis:', err);
    }
  }

  private toggleSettings() {
    this.showSettings = !this.showSettings;
    if (this.showSettings) {
      // Refresh data when opening settings
      this.loadHistory();
    }
  }

  private renderHistoryItem(item: ConversationRecord) {
    const title = item.transcript
      ? `Listen to "${item.transcript.substring(0, 50)}..."`
      : `Listen to audio for "${item.name}"`;

    return html`
      <li>
        <a
          href=${ifDefined(item.audio_url ?? undefined)}
          target="_blank"
          title=${title}
          >${item.name}</a
        >
      </li>
    `;
  }

  renderMainUI() {
    return html`
      <gdm-live-audio-visuals-3d
        .inputNode=${this.inputNode}
        .outputNode=${this.outputNode}
      ></gdm-live-audio-visuals-3d>
      <div
        class="settings-icon"
        @click=${this.toggleSettings}
        role="button"
        aria-label="Open Settings"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          height="28px"
          viewBox="0 -960 960 960"
          width="28px"
          fill="#ffffff"
        >
          <path
            d="m481-320 189-109-189-109v-122l318 183-318 183v-122Zm-241 80q-33 0-56.5-23.5T160-320v-320q0-33 23.5-56.5T240-720h480q33 0 56.5 23.5T800-640v320q0 33-23.5 56.5T720-240H240Z"
          />
        </svg>
      </div>

      <div class="controls">
        <div
          class="puck ${this.isRecording ? 'recording' : ''}"
          @click=${this.toggleRecording}
          aria-label=${this.isRecording ? 'Stop listening' : 'Start listening'}
        ></div>
      </div>
    `;
  }

  renderSettingsUI() {
    const formatCurrency = (amount: number) =>
      new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
      }).format(amount);

    const historyContent =
      this.history.length > 0
        ? html`<ul>
            ${this.history.map((item) => this.renderHistoryItem(item))}
          </ul>`
        : html`<p>No conversations saved yet.</p>`;

    return html`
      <div class="settings-overlay">
        <div class="settings-header">
          <h2>Settings & Reports</h2>
          <button
            class="close-button"
            @click=${this.toggleSettings}
            aria-label="Close Settings"
          >
            &times;
          </button>
        </div>
        <div class="settings-content">
          <div class="panel history-panel">
            <h3>Maximus' Memory</h3>
            ${historyContent}
          </div>

          <div class="panel financial-panel">
            <h3>Magnus' Daily Report</h3>
            <div class="financial-summary">
              <span class="income"
                >Income: ${formatCurrency(this.dailyFinancials.income)}</span
              >
              <span class="expenses"
                >Expenses: ${formatCurrency(this.dailyFinancials.expenses)}</span
              >
              <p>${this.dailyFinancials.summary}</p>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  render() {
    return this.showSettings ? this.renderSettingsUI() : this.renderMainUI();
  }
}